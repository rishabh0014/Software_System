/*
============================================================================
Name : 2.c
Author : Rishabh Teli
Description : 2. Write a simple program to execute in an infinite loop at the background. Go to /proc directory and identify all the process related information in the corresponding proc directory.
============================================================================
*/
#include<stdio.h>

int main(){

    while(1){

    }
    return 0;
}